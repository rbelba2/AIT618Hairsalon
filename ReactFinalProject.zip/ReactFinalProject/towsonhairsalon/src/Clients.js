import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import backgroundPhoto from './salon_tools.jpg';

class Clients extends Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }

    render() {
        return (
            <div style={{ textAlign: "center" }}>
                <div style={{ position: "fixed", marginLeft: "40%" }}>
                    <h1>Clients</h1>
                    <Link to='/home'>
                        <button className="btn btn-primary">Home</button>
                    </Link><br /><br />
                    <Link to='/'>
                        <button className="btn btn-primary">Logout</button>
                    </Link>
                </div>
                <img src={backgroundPhoto} className="App-logo" alt="logo" />
            </div>
        )
    }
}

export default Clients;