import React from 'react';
import { Link } from 'react-router-dom';
import backgroundPhoto from './salon_tools.jpg';

import './App.css';

function Login() {
    return (
        <div className="App">
            <header className="App-header">
                <div className="jumbotron">
                    <h1>Towson Hair Salon</h1>
                    <form>
                        <h3>Sign In</h3>
                        <div className="form-group">
                            <label style={{ paddingRight: '10px' }}>Email  </label>
                            <input type="email" className="form-control" placeholder="Enter email" />
                        </div>
                        <div className="form-group">
                            <label style={{ paddingRight: '10px' }}>Password</label>
                            <input type="password" className="form-control" placeholder="Enter password" />
                        </div>
                        <br />
                        <Link to='/home'>
                            <button className="btn btn-primary">Submit</button>
                        </Link>
                    </form>
                </div>
                <img src={backgroundPhoto} className="App-logo" alt="logo" />
            </header>
        </div>
    );
}

export default Login;
