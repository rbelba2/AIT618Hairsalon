var MongoClient = require('mongodb').MongoClient;
var url= "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
	if (err) throw err;
	var dbo = db.db("towsondb")
	var towsonobj = [

	{ id: 1, fname:'Jan', lname:'Alders', phone:'410-555-9087', email:'jalder@aol.com', notes:'blowdry'},
	{ id: 2, fname:'Joe', lname:'Ailey', phone:'410-555-6077', email:'janderson@gmail.com', notes:'haircut'},
	{ id: 3, fname:'Beth', lname:'Andrews', phone:'410-555-9177', email:'beth@aol.com', notes:'color'},
	{ id: 4, fname:'Tiffanie', lname:'Brown', phone:'202-555-9078', email:'tbrown@comcast.net', notes:'blowdry'},
	{ id: 5, fname:'Mia', lname:'Carter', phone:'410-555-9077', email:'MCarter@aol.com', notes:'perm'},
	{ id: 6, fname:'Tom', lname:'Clark', phone:'301-555-5077', email:'clark1@yahoo.com', notes:'color'},
	{ id: 7, fname:'Nina', lname:'Davis', phone:'410-555-9057', email:'Nina1@aol.com', notes:'blowdry'},
	{ id: 8, fname:'Sean', lname:'Halls', phone:'410-499-1067', email:'Sean2@aol.com', notes:'cut'},
	{ id: 9, fname:'Ann', lname:'Garrison', phone:'410-555-3421', email:'AnnG@yahoo.com', notes:'color'},
	{ id: 10, fname:'Peter', lname:'Harrison', phone:'410-555-5177', email:'pete@aol.com', notes:'blowdry'},
	];
	dbo.collection('clients').insertMany(towsonobj, function(err, res){
		if(err) throw err;
		console.log('Number of documents inserted:'+ res.insertedCount);
		db.close();
	});
	});
