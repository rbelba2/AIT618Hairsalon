import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import backgroundPhoto from './salon_tools.jpg';

class Home extends Component {
    constructor(props) {
        super(props)
        this.state = {

        }

    }

    render() {
        return (
            <div style={{textAlign: "center"}}>
                <div style={{position: "fixed", marginLeft: "30%"}}>
                    <h1>Welcome to Towson Hair Salon</h1>
                    <Link to='/schedule'>
                        <button className="btn btn-primary">Schedule</button>
                    </Link><br /><br />
                    <Link to='/employees'>
                        <button className="btn btn-primary">Employees</button>
                    </Link><br /><br />
                    <Link to='/clients'>
                        <button className="btn btn-primary">Clients</button>
                    </Link><br /><br />
                    <Link to='/contact'>
                        <button className="btn btn-primary">Contact</button>
                    </Link><br /><br />
                    <Link to='/'>
                        <button className="btn btn-primary">Logout</button>
                    </Link>
                </div>
                <img src={backgroundPhoto} className="App-logo" alt="logo" />
            </div>
        )
    }
}

export default Home;