var MongoClient = require('mongodb').MongoClient;
var url= "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
	if (err) throw err;
	var dbo = db.db("towsondb")
	var towsonobj = [

	{ id: 1, fname:'Inga', lname:'Adkins', phone:'410-555-6447', email:'Inga@gmail.com', position:'Stylist'},
	{ id: 2, fname:'Pamela', lname:'Ailey', phone:'410-555-9104', email:'Pamela@aol.com', position:'Stylist'},
	{ id: 3, fname:'Timothy', lname:'Bowman', phone:'410-555-9078', email:'Bowman@comcast.net', position:'Stylist'},
	{ id: 4, fname:'Cynthia', lname:'Caal', phone:'202-555-9922', email:'Caalgirl@aol.com', position:'Stylist'},
	{ id: 5, fname:'Jesse', lname:'Campbell', phone:'410-555-5077', email:'JesseC@yahoo.com', position:'Stylist'},
	{ id: 6, fname:'Rachel', lname:'Davis', phone:'301-555-2051', email:'Rachel1@aol.com', position:'Stylist'},
	{ id: 7, fname:'Anna', lname:'Gains', phone:'410-555-3121', email:'AGains@yahoo.com', position:'Stylist'},
	{ id: 8, fname:'Kayla', lname:'Halls', phone:'410-499-0896', email:'kdrodge4@gmail.com', position:'Stylist'},
	{ id: 9, fname:'Ray', lname:'Harris', phone:'410-555-5173', email:'RayHarris@aol.com', position:'Stylist'},
	{ id: 10, fname:'Kevin', lname:'Johnson', phone:'410-555-2222', email:'Johnson@aol.com', position:'Stylist'},
	{ id: 11, fname:'Leena', lname:'Jung', phone:'410-555-3788', email:'Leena3@yahoo.com', position:'Stylist'},
	{ id: 12, fname:'Tina', lname:'Kelly', phone:'443-555-9139', email:'443-555-9139', position:'Stylist'},
	];
	dbo.collection('employees').insertMany(towsonobj, function(err, res){
		if(err) throw err;
		console.log('Number of documents inserted:'+ res.insertedCount);
		db.close();
	});
	});
