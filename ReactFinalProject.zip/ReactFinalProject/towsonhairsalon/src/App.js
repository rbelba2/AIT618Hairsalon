import React from 'react';
import RoutingConfig from './router';

import './App.css';

function App() {
  return (
    <RoutingConfig />
  );
}

export default App;
