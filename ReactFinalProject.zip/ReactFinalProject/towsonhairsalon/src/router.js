import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';

import Login from './Login';
import Home from './Home';
import Schedule from './Schedule';
import Employees from './Employees';
import Clients from './Clients';
import Contact from './Contact';

const RoutingConfig = () => (
    <Router>
        <div>
            <Route exact path="/" component={Login} />
            <Route path="/home" component={Home} />
            <Route path='/schedule' component={Schedule} />
            <Route path='/employees' component={Employees} />
            <Route path='/clients' component={Clients} />
            <Route path='/contact' component={Contact} />
        </div>
    </Router>
);

export default RoutingConfig;